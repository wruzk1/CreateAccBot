import requests,re,redis,threading,asyncio,os,sys,gc,json,time,stem.process
from random import randint
import subprocess as sp

TYPECR = "PYRO"
try:
    TYPECR = sys.argv[1]
except:
    print("NO TYPECR")
    
PHONE = ""
try:
    PHONE = sys.argv[2]
except:
    print("NO PHONE")     

IDS = ""
try:
    IDS = sys.argv[3]
except:
    print("NO IDS")   

OPRX = ""
try:
    OPRX = sys.argv[4]
except:
    print("NO OPR")  
   
CHATID = ""
try:
    CHATID = sys.argv[5]
except:
    print("NO CHATID") 

THE = ""
try:
    THE = sys.argv[6]
except:
    print("NO THE")  

APIID = ""
try:
    APIID = sys.argv[7]
except:
    print("NO APIID") 

APIHASH = ""
try:
    APIHASH = sys.argv[8]
except:
    print("NO APIHASH") 
    
SITE = ""
try:
    SITE = sys.argv[9]
except:
    print("NO SITE")      
db = None
while not db :
    db = redis.StrictRedis(host='localhost', port=6379, db=0,decode_responses=True)
    
from pyrogram import Client
from pyrogram import filters
from pyrogram import idle
from pyrogram import errors
from pyrogram.types import InlineKeyboardButton as button
from pyrogram.types import InlineKeyboardMarkup as markup
from pyrogram.types import ForceReply as reply
from pyrogram.raw import functions
from telethon import TelegramClient, events, functions, types
from telethon import errors as errors2
from telethon.errors import SessionPasswordNeededError
if db.get("SATOKEN"):
    SATOKEN = db.get("SATOKEN")
else:
    SATOKEN = ""
if db.get("S5TOKEN"):
    S5TOKEN = db.get("S5TOKEN")
else:
    S5TOKEN = ""
if db.get("SCTOKEN"):
    SCTOKEN = db.get("SCTOKEN")
else:
    SCTOKEN = ""
if db.get("SMTOKEN"):
    SMTOKEN = db.get("SMTOKEN")
else:
    SMTOKEN = ""
from time import sleep
global step
step= 'None'
SORP = "SERI"
SOSK = 0
NASK = 0
def print_bootstrap_lines(line):
    print(line)
def changeIP(PORT):
    os.system("sudo fuser -k " + str(PORT) + "/tcp")
    result = None
    try:
        tor_process = stem.process.launch_tor_with_config(config = {'SocksPort': str(PORT),'DataDirectory': './.tordatach' + str(PORT),},init_msg_handler = print_bootstrap_lines,)
        result = "Yes"
    except:
        pass
PORTX = 9051
async def TELETHON1(clientT,PHONE,PORTX,ID,OPR,TOKEN,chat_id,SITE):
    global OUTED
    print("IN CREATE THON")
    global NASK
    global SORP
    if SITE == "5sim":
        # headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
        # READY = requests.get(f"https://5sim.net/v1/user/check/{ID}", headers=headers)
        pass
    elif SITE == "sa":
        READY = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
    elif SITE == "sm":
        # READY = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
        READY = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=ready")
        print(READY.json())
        READY = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?action=setStatus&api_key={TOKEN}&id={ID}&status=1")
        print(READY.content)
    else:
        READY = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
    try:
        await clientT.connect()
        print("CONNECT TELEGRAM")
        phone_code_hash1 = ""
        phone_code_hash1 = await clientT.send_code_request(f"+{PHONE}")
        print(phone_code_hash1)
    except errors2.PhoneNumberInvalidError:
        print("PhoneNumberInvalid")
        db.sadd("BANNED",f"{PHONE}")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
      #  sys.exit()
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    except Exception as e: 
        print(e)
        db.sadd("BANNED",f"{PHONE}")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    except:
        print("EXCEPT")
        db.sadd("BANNED",f"{PHONE}")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    CodeGo = ""
    TIMETC = 0
    while True:
        if TIMETC < 180:
            TIMETC += 1
            STATUS = ""
            if SITE == "5sim":
                headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                STATUS = requests.get(f"https://5sim.net/v1/user/check/{ID}", headers=headers)
                try:
                    print(STATUS.content)
                except:
                    print(STATUS)
                try:
                    STATUSC = STATUS.json()["status"]
                    if (STATUSC == "FINISHED" or STATUSC == "RECEIVED") and len(STATUS.json()["sms"]) > 0:
                        for XCODE in STATUS.json()["sms"]:
                            CodeGo = XCODE["code"]
                        break
                except Exception as e: print(e)
                except: pass
            elif SITE == "sa":
                STATUS = requests.get(f"https://api.sms-activate.org/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                STATUSC = ""
                try:
                    STATUSC = str(STATUS.content)
                except: 
                    STATUSC = str(STATUS)
                print(STATUSC)
                if "STATUS_OK" in STATUSC:
                    CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                    break
            elif SITE == "sm":
                # STATUS = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                STATUS = requests.get(f"http://api.sms-man.com/control/get-sms?token={TOKEN}&request_id={ID}")
                STATUSC = ""
                try:
                    STATUSC = STATUS.json()
                    print(STATUSC)
                    if STATUSC["sms_code"]:
                        STATUSC = "STATUS_OK:" + str(STATUSC["sms_code"])
                    else:
                        STATUSC = "STATUS_WAITING"
                except Exception as e:
                    print(e)
                    STATUSC = "STATUS_WAITING"
                except:
                    print("Except")
                    STATUSC = "STATUS_WAITING"
                # STATUSC = ""
                # try:
                    # STATUSC = str(STATUS.content)
                # except: 
                    # STATUSC = str(STATUS)
                # print(STATUSC)
                if "STATUS_OK" in STATUSC:
                    CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                    break
            else:
                STATUS = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                STATUSC = ""
                try:
                    STATUSC = str(STATUS.content)
                except: 
                    STATUSC = str(STATUS)
                print(STATUSC)
                if "STATUS_OK" in STATUSC:
                    CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                    break
        else:
            db.sadd("AFTERTIME",f"{PHONE}")
            print("NO CODE")
            break
        await asyncio.sleep(1)
    if CodeGo == "":
        print("FUCK IT")
        db.sadd("BANNED",f"{PHONE}")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    try:
        print("SIGN IN")
        RESULTA = await clientT.sign_in(phone=f"+{PHONE}", code=CodeGo)
        print(RESULTA)
    except errors2.PhoneNumberUnoccupiedError:
        print("REG")
        try:
            if db.get("NASK"):
                NASK = int(db.get("NASK"))
            if db.scard("NAMES") > 0:
                TNN = 0
                if NASK >= db.scard("NAMES"):
                    NASK = 0
                    db.set("NASK","0")
                for GNAME in db.smembers("NAMES"):
                    TNN += 1
                    if TNN > NASK:
                        NASK = TNN
                        db.set("NASK",str(TNN))
                        break
                GNAME = GNAME
                GNAMES = GNAME.split(" ")
                FNAME = GNAMES[0]
                LNAME = GNAMES[1]
            else:
                FNAME = "Torsten"
                LNAME = "Eichmann"
            RESULTA = await clientT.sign_up(code=CodeGo, first_name=str(FNAME), last_name=str(LNAME)) 
            print(RESULTA)
        except Exception as e: print(e)
    except Exception as e:
        db.sadd("BANNED",f"{PHONE}")
        print(e)
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    except:
        db.sadd("BANNED",f"{PHONE}")
        print("EXCEPT")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        try:
            await clientT.disconnect()
        except: pass
        return
    db.sadd("PHONESALL",PHONE)
    db.set(PHONE,"THON")
    db.sadd("CREATED",f"{PHONE}:TELETHON:{CodeGo}")
    try:
        print("PHOTO")
        if db.get("SOSK"):
            SOSK = int(db.get("SOSK"))
        if SORP == "SERI":
            if db.scard("SERI") > 0:
                TIN = 0
                if SOSK >= db.scard("SERI"):
                    SORP = "PHOT"
                    SOSK = 0
                    db.set("SOSK","0")
                for GPHOTO1 in db.smembers("SERI"):
                    TIN += 1
                    if TIN > SOSK:
                        SOSK = TIN
                        db.set("SOSK",str(TIN))
                        break
                GPHOTO1 = GPHOTO1
                for URLPH in db.smembers(GPHOTO1):
                    URLPH = URLPH
                    try:
                        NO = await clientT(functions.photos.UploadProfilePhotoRequest(await clientT.upload_file(URLPH)))
                    except: pass
            else:
                if db.scard("PHOTOS") > 0:
                    TIN = 0
                    if SOSK >= db.scard("PHOTOS"):
                        SORP = "SERI"
                        SOSK = 0
                        db.set("SOSK",str(0))
                    for GPHOTO in db.smembers("PHOTOS"):
                        TIN += 1
                        if TIN > SOSK:
                            SOSK = TIN
                            db.set("SOSK",str(TIN))
                            break
                    GPHOTO = GPHOTO
                    try:
                        NO = await clientT(functions.photos.UploadProfilePhotoRequest(await clientT.upload_file(GPHOTO)))
                    except: pass
        elif SORP == "PHOT":
            if db.scard("PHOTOS") > 0:
                TIN = 0
                if SOSK >= db.scard("PHOTOS"):
                    SORP = "SERI"
                    SOSK = 0
                    db.set("SOSK",str(0))
                for GPHOTO in db.smembers("PHOTOS"):
                    TIN += 1
                    if TIN > SOSK:
                        SOSK = TIN
                        db.set("SOSK",str(TIN))
                        break
                GPHOTO = GPHOTO
                try:
                    NO = await clientT(functions.photos.UploadProfilePhotoRequest(await clientT.upload_file(GPHOTO)))
                except: pass
            else:
                TIN = 0
                if SOSK >= db.scard("SERI"):
                    SORP = "PHOT"
                    SOSK = 0
                    db.set("SOSK",str(0))
                for GPHOTO1 in db.smembers("SERI"):
                    TIN += 1
                    if TIN > SOSK:
                        SOSK = TIN
                        db.set("SOSK",str(TIN))
                        break
                GPHOTO1 = GPHOTO1
                for URLPH in db.smembers(GPHOTO1):
                    URLPH = URLPH
                    try:
                        NO = await clientT(functions.photos.UploadProfilePhotoRequest(await clientT.upload_file(URLPH)))
                    except: pass
        OUTED = True
        print("END CREATE")
        try:
            await clientT.disconnect()
        except: pass
        return True
    except Exception as e: print(e)
    except:
        pass
    OUTED = True
    try:
        await clientT.disconnect()
    except: pass
    return


async def PYROG(PHONE,api_id, api_hash, PORTX, OPR,ID,TOKEN,chat_id,SITE):
    global OUTED
    print("IN CREATE PYRO")
    global NASK
    global SORP
    session = f'sessions/+{PHONE}'
    proxy = {"scheme": "socks5","hostname": "127.0.0.1","port": int(PORTX),"username": "","password": ""}
    client = ""
    if SITE == "5sim":
        # headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
        # READY = requests.get(f"https://5sim.net/v1/user/check/{ID}", headers=headers)
        pass
    elif SITE == "sa":
        READY = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
    elif SITE == "sm":
        # READY = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
        READY = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=ready")
        print(READY.json())
        READY = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?action=setStatus&api_key={TOKEN}&id={ID}&status=1")
        print(READY.content)
    else:
        READY = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=1&id={ID}")
    try:
        client = Client(session,api_id,api_hash,proxy=proxy)
        await client.connect()
        print("CONNECT TELEGRAM")
        phone_code_hash1 = await client.send_code(f"+{PHONE}")
        print(phone_code_hash1)
        phone_code_hash = phone_code_hash1.phone_code_hash
        # phone_code_hash2 = ""
        if phone_code_hash1.next_type and phone_code_hash1.next_type == "sms":
            db.sadd("BANNED",f"{PHONE}")
            if SITE == "5sim":
                headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
            elif SITE == "sa":
                DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
            elif SITE == "sm":
                # DELETE = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
            else:
                DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
            OUTED = True
            print("NO SMS")
            try:
                await client.disconnect()
            except: pass
            try:
                await client.stop()
            except: pass
            return False
        else:
            print("Ready")
            TIMETC = 0
            CodeGo = ""
            RESEND = False
            while True:
                if TIMETC < 180:
                    # if TIMETC > 100 and RESEND == False:
                        # RESEND = True
                        # try:
                            # phone_code_hash1 = await client.resend_code(phone_number=f"+{PHONE}",phone_code_hash=phone_code_hash)
                            # print(phone_code_hash1)
                            # phone_code_hash2 = phone_code_hash1.phone_code_hash
                        # except Exception as e:
                            # print(e)
                        # except: pass
                    TIMETC += 1
                    STATUSC = ""
                    if SITE == "5sim":
                        headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                        STATUS = requests.get(f"https://5sim.net/v1/user/check/{ID}", headers=headers)
                        try:
                            print(STATUS.content)
                        except: 
                            print(STATUS)
                        try:
                            STATUSC = STATUS.json()["status"]
                            if (STATUSC == "FINISHED" or STATUSC == "RECEIVED") and len(STATUS.json()["sms"]) > 0:
                                for XCODE in STATUS.json()["sms"]:
                                    CodeGo = XCODE["code"]
                                    print(CodeGo)
                                break
                        except Exception as e: print(e)
                        except: pass
                    elif SITE == "sa":
                        STATUS = requests.get(f"https://api.sms-activate.org/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                        STATUSC = ""
                        try:
                            STATUSC = str(STATUS.content)
                        except: 
                            STATUSC = str(STATUS)
                        print(STATUSC)
                        if "STATUS_OK" in STATUSC:
                            CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                            break
                    elif SITE == "sm":
                        # STATUS = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                        STATUS = requests.get(f"http://api.sms-man.com/control/get-sms?token={TOKEN}&request_id={ID}")
                        STATUSC = ""
                        try:
                            STATUSC = STATUS.json()
                            print(STATUSC)
                            if STATUSC["sms_code"]:
                                STATUSC = "STATUS_OK:" + str(STATUSC["sms_code"])
                            else:
                                STATUSC = "STATUS_WAITING"
                        except Exception as e:
                            print(e)
                            STATUSC = "STATUS_WAITING"
                        except:
                            print("Except")
                            STATUSC = "STATUS_WAITING"
                        # try:
                            # STATUSC = str(STATUS.content)
                        # except: 
                            # STATUSC = str(STATUS)
                        # print(STATUSC)
                        if "STATUS_OK" in STATUSC:
                            CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                            break
                    else:
                        STATUS = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=getStatus&id={ID}")
                        STATUSC = ""
                        try:
                            STATUSC = str(STATUS.content)
                        except: 
                            STATUSC = str(STATUS)
                        print(STATUSC)
                        if "STATUS_OK" in STATUSC:
                            CodeGo = STATUSC.replace("\n","").replace("STATUS_OK:","").replace("b'","").replace("'","")
                            break
                    print(CodeGo)
                else:
                    db.sadd("AFTERTIME",f"{PHONE}")
                    if SITE == "5sim":
                        headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                        DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
                    elif SITE == "sa":
                        DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                    elif SITE == "sm":
                        DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
                    else:
                        DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                    print("After Time")
                    OUTED = True
                    try:
                        await client.disconnect()
                    except: pass
                    try:
                        await client.stop()
                    except: pass
                    return False
                await asyncio.sleep(2)
            if CodeGo != "":
                print("SIGN IN")
                # if phone_code_hash2 != "":
                    # HASH = phone_code_hash2
                # else:
                HASH = phone_code_hash
                OKTRUE = 0
                try:
                    RESULTA = await client.sign_in(phone_number=f"+{PHONE}",phone_code_hash=HASH, phone_code=CodeGo)
                    print(RESULTA)
                    try:
                        IDX = RESULTA.id
                        RESULT = await client.accept_terms_of_service(terms_of_service_id=str(IDX))
                    except Exception as e: print(e)
                    try:
                        print("NAME")
                        if db.get("NASK"):
                            NASK = int(db.get("NASK"))
                        if db.scard("NAMES") > 0:
                            TNN = 0
                            if NASK >= db.scard("NAMES"):
                                NASK = 0
                                db.set("NASK", "0")
                            for GNAME in db.smembers("NAMES"):
                                TNN += 1
                                if TNN > NASK:
                                    NASK = TNN
                                    db.set("NASK", str(TNN))
                                    break
                            GNAME = GNAME
                            GNAMES = GNAME.split(" ")
                            FNAME = GNAMES[0]
                            LNAME = GNAMES[1]
                        else:
                            FNAME = "Torsten"
                            LNAME = "Eichmann"
                        RESULT = await client.sign_up(phone_number=f"+{PHONE}",phone_code_hash= HASH, first_name= str(FNAME) , last_name= str(LNAME))
                        OKTRUE += 1
                    except Exception as e: print(e)
                    db.sadd("PHONESALL",PHONE)
                    db.sadd("CREATED",f"{PHONE}:PYROGRAM:{CodeGo}")
                    try:
                        print("PHOTO")
                        if db.get("SOSK"):
                            SOSK = int(db.get("SOSK"))
                        if SORP == "SERI":
                            if db.scard("SERI") > 0:
                                TIN = 0
                                if SOSK >= db.scard("SERI"):
                                    SORP = "PHOT"
                                    SOSK = 0
                                    db.set("SOSK",str(0))
                                for GPHOTO1 in db.smembers("SERI"):
                                    TIN += 1
                                    if TIN > SOSK:
                                        SOSK = TIN
                                        db.set("SOSK",str(TIN))
                                        break
                                GPHOTO1 = GPHOTO1
                                for URLPH in db.smembers(GPHOTO1):
                                    URLPH = URLPH
                                    await client.set_profile_photo(photo=str(URLPH))
                            else:
                                if db.scard("PHOTOS") > 0:
                                    TIN = 0
                                    if SOSK >= db.scard("PHOTOS"):
                                        SORP = "SERI"
                                        SOSK = 0
                                        db.set("SOSK",str(0))
                                    for GPHOTO in db.smembers("PHOTOS"):
                                        TIN += 1
                                        if TIN > SOSK:
                                            SOSK = TIN
                                            db.set("SOSK",str(TIN))
                                            break
                                    GPHOTO = GPHOTO
                                    await client.set_profile_photo(photo=str(GPHOTO))
                        elif SORP == "PHOT":
                            if db.scard("PHOTOS") > 0:
                                TIN = 0
                                if SOSK >= db.scard("PHOTOS"):
                                    SORP = "SERI"
                                    SOSK = 0
                                    db.set("SOSK",str(0))
                                for GPHOTO in db.smembers("PHOTOS"):
                                    TIN += 1
                                    if TIN > SOSK:
                                        SOSK = TIN
                                        db.set("SOSK",str(TIN))
                                        break
                                GPHOTO = GPHOTO
                                await client.set_profile_photo(photo=str(GPHOTO))
                            else:
                                TIN = 0
                                if SOSK >= db.scard("SERI"):
                                    SORP = "PHOT"
                                    SOSK = 0
                                    db.set("SOSK",str(0))
                                for GPHOTO1 in db.smembers("SERI"):
                                    TIN += 1
                                    if TIN > SOSK:
                                        SOSK = TIN
                                        db.set("SOSK",str(TIN))
                                        break
                                GPHOTO1 = GPHOTO1
                                for URLPH in db.smembers(GPHOTO1):
                                    URLPH = URLPH
                                    await client.set_profile_photo(photo=str(URLPH))
                        OUTED = True
                        print("END CREATE")
                        try:
                            await client.disconnect()
                        except: pass
                        try:
                            await client.stop()
                        except: pass
                        return True
                    except Exception as e: print(e)
                    except: pass
                    OUTED = True
                    try:
                        await client.disconnect()
                    except: pass
                    try:
                        await client.stop()
                    except: pass
                    return False
                except Exception as e: 
                    db.sadd("BANNED",f"{PHONE}")
                    print(e)
                    if SITE == "5sim":
                        headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                        DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
                    elif SITE == "sa":
                        DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                    elif SITE == "sm":
                        DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
                    else:
                        DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                    print("EXCEPTION")
                    OUTED = True
                    try:
                        await client.disconnect()
                    except: pass
                    try:
                        await client.stop()
                    except: pass
                    return False
    except errors.PhoneNumberInvalid as error:
        db.sadd("BANNED",f"{PHONE}")
        print("PhoneNumberInvalid")
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        print("No phone")
        OUTED = True
        try:
            await client.disconnect()
        except: pass
        try:
            await client.stop()
        except: pass
        return False
    except Exception as e: 
        db.sadd("BANNED",f"{PHONE}")
        print(e)
        if SITE == "5sim":
            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
            DELETE = requests.get(f"https://5sim.net/v1/user/ban/{ID}", headers=headers)
        elif SITE == "sa":
            DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        elif SITE == "sm":
            DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={TOKEN}&request_id={ID}&status=reject")
        else:
            DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
        OUTED = True
        print("Exception 2")
        try:
            await client.disconnect()
        except:
            pass
        return False
        
OUTED = False
First = False
while True:
    if OUTED == True:
        break
    STOKEN = ""
    if SITE == "5sim":
        STOKEN = S5TOKEN
    elif SITE == "sa":
        STOKEN = SATOKEN
    elif SITE == "sm":
        STOKEN = SMTOKEN
    else:
        STOKEN = SCTOKEN
    db.sadd("LISTTHE" , str(THE))
    os.system(f"rm -rf sessions/+{PHONE}.session")
    if First == False:
        if TYPECR == "PYRO":
            First = True
            try:
                PORTX = 9050 + int(THE)
                TOR = changeIP(PORTX)
                # loop = asyncio.new_event_loop()
                # asyncio.set_event_loop(loop)
                asyncio.run(PYROG(PHONE,APIID, APIHASH, PORTX, OPRX,IDS,STOKEN,CHATID,SITE))
                # loop.run_until_complete(PYROG(PHONE,APIID, APIHASH, PORTX, OPRX,IDS,STOKEN,CHATID,SITE))
                # loop.close()
            except Exception as e: print(e)
            except: pass
        else:
            First = True
            try:
                PORTX = 9050 + int(THE)
                TOR = changeIP(PORTX)
                # proxy = {'proxy_type': 'socks5','addr': '127.0.0.1','port': int(PORTX),'username': '','password': '','rdns': True}
                clientT = TelegramClient(f'sessions/+{PHONE}', APIID, APIHASH, proxy=("socks5", "127.0.0.1", int(PORTX)))
                clientT.loop.run_until_complete(TELETHON1(clientT,PHONE,PORTX,IDS,OPRX,STOKEN,CHATID,SITE))
                clientT.start()
                clientT.run_until_disconnected()
            except Exception as e: print(e)
            except: pass
    sleep(5)
db.srem("LISTTHE" , str(THE))
print("END")