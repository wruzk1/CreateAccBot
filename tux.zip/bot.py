import requests,re,redis,threading,asyncio,os,sys,gc,json,time,stem.process
import random
from random import randint
import subprocess as sp

db = None
while not db :
    db = redis.StrictRedis(host='localhost', port=6379, db=0,decode_responses=True)
    
from pyrogram import Client
from pyrogram import filters
from pyrogram import idle
from pyrogram import errors
from pyrogram.types import InlineKeyboardButton as button
from pyrogram.types import InlineKeyboardMarkup as markup
from pyrogram.types import ForceReply as reply
from pyrogram.raw import functions
from telethon import TelegramClient, events, functions, types
from telethon import errors as errors2
from telethon.errors import SessionPasswordNeededError
if db.get("TOKEN"):
    STOKEN = db.get("TOKEN")
else:
    print("NO BOT TOKEN")
    sys.exit()
app = Client("bot",8620004,"38c878e9530d1968f28caaae6760fa83",bot_token=STOKEN)
if db.get("SATOKEN"):
    SATOKEN = db.get("SATOKEN")
else:
    SATOKEN = ""
if db.get("S5TOKEN"):
    S5TOKEN = db.get("S5TOKEN")
else:
    S5TOKEN = ""
if db.get("SCTOKEN"):
    SCTOKEN = db.get("SCTOKEN")
else:
    SCTOKEN = ""
if db.get("SMTOKEN"):
    SMTOKEN = db.get("SMTOKEN")
else:
    SMTOKEN = ""
from time import sleep
global step
step= 'None'
SORP = "SERI"
SOSK = 0
NASK = 0
def print_bootstrap_lines(line):
    pass
def changeIP(PORT):
    os.system("sudo fuser -k " + str(PORT) + "/tcp")
    result = None
    try:
        tor_process = stem.process.launch_tor_with_config(config = {'SocksPort': str(PORT),'DataDirectory': './.tordatach' + str(PORT),},init_msg_handler = print_bootstrap_lines,)
        result = "Yes"
    except:
        pass
PORTX = 9051
# AUTOLAUNCH = int(time.time()) + 43200
# ALLKILL = False
TYPECR = "PYRO"
ISCREATE = False

ALLLISTGET = {}
async def GetCode(phone,chat_id):
    Sapp = ""
    global PORTX
    # global ALLKILL
    # global AUTOLAUNCH
    global app
    global ALLLISTGET
    TELTHON = False
    if db.get(phone):
        TELTHON = True
    while True:
        try:
            sessionx = f'sessions/+{phone}'
            PORTX += 1
            if int(PORTX) > 9100:
                PORTX = 9051
            TOR = changeIP(PORTX)
            api_id, api_hash = 16623,"8c9dbfe58437d1739540f5d53c72ae4b"
            if TELTHON == True:
                Sapp = TelegramClient(sessionx, api_id, api_hash, proxy=("socks5", "127.0.0.1", int(PORTX)))
            else:
                Sapp = Client(sessionx,api_id,api_hash,proxy=dict(hostname="127.0.0.1",port=int(PORTX),username="",password=""))  
            break
        except:
            await asyncio.sleep(1)
    is_auth = False
    if TELTHON == True:
        is_auth2 = await Sapp.connect()
        is_auth = await Sapp.is_user_authorized()
    else:
        is_auth = await Sapp.connect()
    if is_auth:
        TRYTIME= 0
        while True:
            TRYTIME += 1
            if TRYTIME > 60:
                ALLLISTGET[str(chat_id)] = False
                await app.send_message(chat_id,f"❌You have reach max time 300 sec")
                db.sadd("PHONESALL",phone)
                try:
                    await Sapp.disconnect()
                except: pass
                try:
                    await Sapp.stop()
                except: pass
                sys.exit()
                break
            # if ALLKILL or int(time.time()) > AUTOLAUNCH:
                # ALLKILL = True
                # ALLLISTGET[str(chat_id)] = False
                # try:
                    # await app.send_message(chat_id,f"❌There is a problem to get code for phone number +{phone}\n Try after a while")
                    # await Sapp.disconnect()
                # except: pass
                # try:
                    # await Sapp.stop()
                # except: pass
                # db.sadd("PHONESALL",phone)
                # sys.exit()
            try:
                if TELTHON == True:
                    async for message in Sapp.iter_messages(777000,limit=5):
                        TEXT = str(message.raw_text)
                        print(TEXT)
                        if "Login code" in TEXT:
                            TEXT = TEXT.replace("1","1️⃣").replace("2","2️⃣").replace("3","3️⃣").replace("4","4️⃣").replace("5","5️⃣").replace("6","6️⃣").replace("7","7️⃣").replace("8","8️⃣").replace("9","9️⃣").replace("0","0️⃣")
                            db.decr(str(chat_id))
                            ALLLISTGET[str(chat_id)] = False
                            await app.send_message(chat_id,f"✅Code received\n\nPhone: +{phone}\nMessage: {TEXT}")
                            try:
                                await Sapp.log_out()
                                TOR.kill()
                            except:
                                pass
                            sys.exit()
                else:
                    async for message in Sapp.iter_history(777000):
                        TEXT = str(message.text)
                        print(TEXT)
                        if "Login code" in TEXT:
                            TEXT = TEXT.replace("1","1️⃣").replace("2","2️⃣").replace("3","3️⃣").replace("4","4️⃣").replace("5","5️⃣").replace("6","6️⃣").replace("7","7️⃣").replace("8","8️⃣").replace("9","9️⃣").replace("0","0️⃣")
                            db.decr(str(chat_id))
                            ALLLISTGET[str(chat_id)] = False
                            await app.send_message(chat_id,f"✅Code received\n\nPhone: +{phone}\nMessage: {TEXT}")
                            try:
                                await Sapp.log_out()
                                TOR.kill()
                            except:
                                pass
                            sys.exit()
            except Exception as e:
                print(e)
                if "AUTH_KEY_UNREGISTERED" in str(e):
                    await app.send_message(chat_id,f"❌There is no auth!\n\nPhone: +{phone}")
                    ALLLISTGET[str(chat_id)] = False
                    sys.exit()
                    break
            await asyncio.sleep(5)
    else:
        await app.send_message(chat_id,f"❌Number not auth!\n\nPhone: +{phone}")
        ALLLISTGET[str(chat_id)] = False
        sys.exit()

def Between_Get(phone,chat_id):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(GetCode(phone,chat_id))
    loop.close()
# STARTED = False
@app.on_message(filters.command(['start']))
async def start(client,message):
    global STARTED
    # global ALLKILL
    # global AUTOLAUNCH
    # if ALLKILL or int(time.time()) > AUTOLAUNCH:
        # ALLKILL = True
        # sys.exit()
    # if STARTED == False:
        # STARTED = True
        # _thread = threading.Thread(target=Between_Start, args=[]).start()
    chat_id = message.chat.id
    print("START => " + str(chat_id))
    message_id = message.id
    NO = await Menu(chat_id,message_id)
list_a = ["218722292","246212075"]
list_b = ["218722292","246212075"]
STEPALL = "none"
if db.scard("SUDOBOT") > 0:
    for sudoid in db.smembers("SUDOBOT"):
        list_a.append(str(sudoid))
else:
    list_a.append("218722292")
    list_a.append("246212075")
async def Menu(chat_id,message_id):
    global list_a
    if str(chat_id) in list_a:
        NO = await app.send_message(chat_id,
                          "✋🏻Hi\nSelect your action",
                          reply_to_message_id = message_id,
                          reply_markup = markup([
                          [button("📤Buy Auto",callback_data="GETHIT"),button("⚠️Cancel Auto",callback_data="CNCHIT")],
                          [button("📊Number List",callback_data="NUML"),button("🔋Auto List",callback_data="NUMA")],
                          [button("📥Get Sessions",callback_data="GSESS"),button("🪄Set User Sess",callback_data="SUSESS")],
                          [button("📸Add Photo",callback_data="PHOTOADD"),button("✂️Clean Photos",callback_data="PHOTOCLEAN")],
                          [button("🎥Add Series",callback_data="SERIADD"),button("🧹Clean Series",callback_data="SERICLEAN")],
                          [button("⌨️Add Name",callback_data="NAMEADD"),button("🗒Clean Name",callback_data="NAMECLEAN")],
                          [button("🕹Add Sudo",callback_data="ADDS"),button("❌Rem Sudo",callback_data="REMS")],
                          [button("📌Set Token",callback_data="TOKENS"),button("🔌Set ID Hash",callback_data="IDHASH"),button("🆙Set Max",callback_data="SETMAX")]
                          ]))
    elif db.sismember("BUSER",str(chat_id)):
        NO = await app.send_message(chat_id,"✋🏻Hi Customer\nSelect your action",reply_to_message_id = message_id,reply_markup = markup([[button("📤Get Random Number",callback_data="GRNUM")]]))
    else:
        NO = await app.send_message(chat_id,"You can not use this robot",parse_mode='html')
LASTTIMEUP = int(time.time())
SUSUSER = 0
@app.on_message()
async def Updates(app,message):
    global STEPALL
    global list_a
    global list_b
    global GLOBALID
    # global ALLKILL
    # global AUTOLAUNCH
    global SUSUSER
    # if ALLKILL or int(time.time()) > AUTOLAUNCH:
        # ALLKILL = True
        # sys.exit()
    chat_id = message.chat.id 
    text = message.text
    if "IDHASH" == STEPALL and GLOBALID == chat_id:
        STEPALL = "IDHASH2"
        api_id = text
        db.set("AAPIID",text)
        await app.send_message(chat_id,f"✅Please send API Hash",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif "SETMAX" == STEPALL and GLOBALID == chat_id:
        STEPALL = "none"
        db.set("MAXLOOP",text)
        await app.send_message(chat_id,f"✅Max loop set",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif "TOKENS_" in STEPALL and GLOBALID == chat_id:
        GETPLAT = STEPALL.replace("TOKENS_","")
        STEPALL = "none"
        db.set(GETPLAT,text)
        await app.send_message(chat_id,f"✅Token Set",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif "IDHASH2" == STEPALL and GLOBALID == chat_id:
        STEPALL = "none"
        api_hash = text
        db.set("AAPIHASH",text)
        await app.send_message(chat_id,f"✅Hash and ID set!",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif "GSESS_" in STEPALL and GLOBALID == chat_id:
        GETPLAT = STEPALL.replace("GSESS_","")
        STEPALL = "none"
        MAXIMPH = db.scard("PHONESALL")
        if text and int(text) > MAXIMPH:
            await app.send_message(chat_id,f"❌Max is {MAXIMPH}",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif text:
            os.system("rm -rf sess")
            os.system("mkdir sess")
           # PHLIST = db.srandmember("PHONESALL",int(text))
            NLIST = 0
            for LPH in db.smembers("PHONESALL"):
                if NLIST >= int(text):
                    break
                if GETPLAT == "THON" and db.get(LPH):
                    NLIST += 1
                    os.system(f'mv sessions/+{LPH}.session sess')
                    db.srem("PHONESALL",LPH)
                elif GETPLAT == "PYRO" and not db.get(LPH):
                    NLIST += 1
                    os.system(f'mv sessions/+{LPH}.session sess')
                    db.srem("PHONESALL",LPH)
            os.system(f'rm -rf sess.zip*')
            os.system(f'zip -r sess.zip sess')
            await app.send_document(chat_id, "sess.zip", caption=f"include {NLIST} sessions")
            await app.send_message(chat_id,f"✅Zip file created and sent",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif STEPALL == "SUSESS":
        STEPALL = "SUSESS2"
        SUSUSER = str(text)
        await app.send_message(chat_id,f"✅Now send user ID",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif STEPALL == "SUSESS2":
        STEPALL = "none"
        db.sadd("BUSER",text)
        db.set(text,SUSUSER)
        if GLOBALID == "THON":
            db.set(str(text) + "T","THON")
        else:
            db.set(str(text) + "T","PYRO")
        await app.send_message(chat_id,f"✅Set {SUSUSER} session for User {text} with platform {GLOBALID}",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif STEPALL == "NAMEADD":
        if " " in str(text):
            db.sadd("NAMES",text)
            await app.send_message(chat_id,f"Name {text} added to list\nAny name? send it",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        else:
            await app.send_message(chat_id,f"❌Wrong name!No space in Name\nAny name? send it",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    
    else:
        if str(chat_id) in list_b:
            if STEPALL == "ADDS": 
                STEPALL = "none"
                db.sadd("SUDOBOT",text)
                list_a.append(text)
                await app.send_message(chat_id,f"User ID {text} added as Sudo",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
            elif STEPALL == "REMS": 
                db.srem("SUDOBOT",text)
                list_a.remove(text)
                STEPALL = "none"
                await app.send_message(chat_id,f"User ID {text} removed from Sudo",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
GLOBALD = {}
SESSIONS = {}
GLOBALID = "123456798"
SERIIDS = 0
sdata = ""
sdata2 = ""
ALLAUTO = False
NOCODE = False
COUNTCODE = "0"
SITE = "sa"
PLATFORM = "THON"
GLOBTHE = 0
LISTSA = []
LISTSM = []
LIST5S = {}
SINGLE = False
api_id, api_hash = 16623,"8c9dbfe58437d1739540f5d53c72ae4b"
if db.get("AAPIID") and db.get("AAPIHASH"):
    api_id = int(db.get("AAPIID"))
    api_hash = db.get("AAPIHASH")
@app.on_callback_query()
async def querys(_, query):
    global LISTSA
    global LISTSM
    global LIST5S
    global GLOBALD
    global STEPALL
    global SINGLE
    global list_b
    global list_a
    global TOKEN
    global SESSIONS
    global GLOBALID
    global LASTTIMEUP
    global PORTX
    global ALLAUTO
    global SITE
    global PLATFORM
    global ALLLISTGET
    global TYPECR
    global ISCREATE
    global NOCODE
    global COUNTCODE
    global GLOBTHE
    global api_id
    global api_hash
    chat_id = query.message.chat.id
    message_id = query.message.id
    data = query.data
    if str(chat_id) in list_a:
        if data == "BACK":
            STEPALL = "none"
            await app.edit_message_text(chat_id,message_id,"✋🏻Hi\nSelect your action",reply_markup = markup([
            [button("📤Buy Auto",callback_data="GETHIT"),button("⚠️Cancel Auto",callback_data="CNCHIT")],
            [button("📊Number List",callback_data="NUML"),button("🔋Auto List",callback_data="NUMA")],
            [button("📥Get Sessions",callback_data="GSESS"),button("🪄Set User Sess",callback_data="SUSESS")],
            [button("📸Add Photo",callback_data="PHOTOADD"),button("✂️Clean Photos",callback_data="PHOTOCLEAN")],
            [button("🎥Add Series",callback_data="SERIADD"),button("🧹Clean Series",callback_data="SERICLEAN")],
            [button("⌨️Add Name",callback_data="NAMEADD"),button("🗒Clean Names",callback_data="NAMECLEAN")],
            [button("🕹Add Sudo",callback_data="ADDS"),button("❌Rem Sudo",callback_data="REMS")],
            [button("📌Set Token",callback_data="TOKENS"),button("🔌Set ID Hash",callback_data="IDHASH"),button("🆙Set Max",callback_data="SETMAX")]]))
        elif data == "TOKENS":
            await app.edit_message_text(chat_id,message_id,"Please select your site",reply_markup = markup([[button(f"5sim",callback_data="TOKENS_S5TOKEN"),button(f"sms-active",callback_data="TOKENS_SATOKEN"),button(f"sms-code",callback_data="TOKENS_SCTOKEN"),button(f"sms-man",callback_data="TOKENS_SMTOKEN")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "TOKENS_" in data:
            STEPALL = data
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Please send your Token",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "SETMAX":
            STEPALL = "SETMAX"
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Please send your Max looping",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "IDHASH":
            STEPALL = "IDHASH"
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Please send your API ID",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "GSESS":
            await app.edit_message_text(chat_id,message_id,"Select your platform",reply_markup = markup([[button(f"TELETHON",callback_data="GSESS2_THON"),button(f"PYROGRAM",callback_data="GSESS2_PYRO")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "GSESS2_" in data:
            GST = data.replace("GSESS2_","")
            STEPALL = "GSESS_" + str(GST)
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Send your number of sessions",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "SUSESS":
            await app.edit_message_text(chat_id,message_id,"Select your platform",reply_markup = markup([[button(f"TELETHON",callback_data="SUSESS2_THON"),button(f"PYROGRAM",callback_data="SUSESS2_PYRO")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "SUSESS2_" in data:
            GST = data.replace("SUSESS2_","")
            STEPALL = "SUSESS"
            GLOBALID = GST
            await app.edit_message_text(chat_id,message_id,"Send how many sessions user can get",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "SERIADD":
            global SERIIDS
            SERIIDS = randint(999,99999)
            STEPALL = "SERIADD"
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Please send your photo",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "PHOTOADD":
            STEPALL = "PHOTOADD"
            GLOBALID = chat_id
            await app.edit_message_text(chat_id,message_id,"Please send your photo",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "NAMEADD":
            STEPALL = "NAMEADD"
            await app.edit_message_text(chat_id,message_id,"Please send your name",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "SERICLEAN":
            if db.scard("SERI") > 0:
                for names in db.smembers("SERI"):
                    names = names
                    db.srem("SERI",names)
                    if db.scard(names) > 0:
                        for serid in db.smembers(names):
                            serid = serid
                            db.srem(names,serid)
            await app.edit_message_text(chat_id,message_id,f"List of Series cleaned",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "CNCHIT":
            ALLAUTO = False
            await app.edit_message_text(chat_id,message_id,f"Auto but canceled!",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "PHOTOCLEAN":
            if db.scard("PHOTOS") > 0:
                for names in db.smembers("PHOTOS"):
                    names = names
                    db.srem("PHOTOS",names)
            await app.edit_message_text(chat_id,message_id,f"List of photos cleaned",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "NAMECLEAN":
            if db.scard("NAMES") > 0:
                for names in db.smembers("NAMES"):
                    names = names
                    db.srem("NAMES",names)
            await app.edit_message_text(chat_id,message_id,f"List of name cleaned",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "ADDS":
            if str(chat_id) in list_b:
                STEPALL = "ADDS"
                await app.edit_message_text(chat_id,message_id,"Please send Sudo ID",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
            else:
                await app.edit_message_text(chat_id,message_id,"You don't have permission",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "REMS":
            if str(chat_id) in list_b:
                STEPALL = "REMS"
                await app.edit_message_text(chat_id,message_id,"Please send Sudo ID",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
            else:
                await app.edit_message_text(chat_id,message_id,"You don't have permission",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "NUMA":
            TLIST = db.scard("PHONESALL")
            await app.edit_message_text(chat_id,message_id,f"You have {TLIST} sessions",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif data == "NUML":
            BUTLI = []
            for ID in GLOBALD:
                CHATID = GLOBALD[ID]["chat"]
                if CHATID == chat_id:
                    PHONE = GLOBALD[ID]["phone"]
                    STATUS = GLOBALD[ID]["status"]
                    if STATUS == "ok":
                        STATUSC = "♻️"
                    else:
                        STATUSC = "❌"
                    BUTLI.append([button(f"☎️+{PHONE} {STATUSC}",callback_data=f"CANCEL_{ID}")])
            BUTLI.append([button(f"🔙Back",callback_data="BACK")])
            await app.edit_message_text(chat_id,message_id,"📊Your number list\nClick on button to cancel it\nFormat: NUMBER STATUS",reply_markup = markup(BUTLI))
        elif data == "GETHIT":
            await app.edit_message_text(chat_id,message_id,"Select Your platform",reply_markup = markup([[button("TELETHON",callback_data="GETHIT2_THON"),button("PYROGRAM",callback_data="GETHIT2_PYRO")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "GETHIT2_" in data:
            TYPECR = data.replace("GETHIT2_","")
            PLATFORM = TYPECR
            await app.edit_message_text(chat_id,message_id,"Select Your site",reply_markup = markup([[button("5 SIM",callback_data="GETHIT3_5sim"),button("SMS ACTIVE",callback_data="GETHIT3_sa")],[button("SMS MAN",callback_data="GETHIT3_sm"),button("SMS CODE",callback_data="GETHIT3_sc")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "GETHIT3_" in data:
            SITE = data.replace("GETHIT3_","")
            await app.edit_message_text(chat_id,message_id,"In range or one country?",reply_markup = markup([[button("Range < 20",callback_data="GETHIT4_20"),button("Range < 16",callback_data="GETHIT4_16")],[button("Range < 15",callback_data="GETHIT4_15"),button("Range < 14",callback_data="GETHIT4_14")],[button("Range < 13",callback_data="GETHIT4_13"),button("Range < 12",callback_data="GETHIT4_12")],[button("One Country",callback_data="GETHIT4_one")],[button(f"🔙Back",callback_data="BACK")]]))
        elif "GETHIT4_" in data:
            if SITE == "5sim":
                TOKEN = S5TOKEN
            elif SITE == "sa":
                TOKEN = SATOKEN
            elif SITE == "sm":
                TOKEN = SMTOKEN
            else:
                TOKEN = SCTOKEN
            SINGLE = data.replace("GETHIT4_","")
            if SINGLE != "one":
                if SITE == "sa":
                    ALLCONP = {}
                    try:
                        ALLCON = requests.get(f"https://api.sms-activate.org/stubs/handler_api.php?api_key={TOKEN}&action=getPrices&service=tg")
                        ALLCONP = ALLCON.json()
                        await asyncio.sleep(0.1)
                    except: pass
                    for COT in ALLCONP:
                        COUNT = ALLCONP[COT]["tg"]["count"]
                        COST = ALLCONP[COT]["tg"]["cost"]
                        if int(COUNT) > 0 and int(float(COST)) < int(SINGLE):
                            LISTSA.append(COT)
                    getl = len(LISTSA)
                    await app.edit_message_text(chat_id,message_id,f"📤Start with {getl} country?\nUnder {SINGLE} Ruble",reply_markup = markup([[button(f"✅Start",callback_data="BUY_RANGE")],[button(f"🔙Back",callback_data="BACK")]]))
                elif SITE == "sm":
                    ALLCONP = {}
                    try:
                        # ALLCON = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?action=getPrices&api_key={TOKEN}&service=tg")
                        ALLCON = requests.get(f"http://api.sms-man.com/control/get-prices?token={TOKEN}")
                        ALLCONP = ALLCON.json()
                        await asyncio.sleep(0.1)
                    except: pass
                    for COT in ALLCONP:
                        # COUNT = ALLCONP[COT]["tg"]["count"]
                        # COST = ALLCONP[COT]["tg"]["cost"]
                        try:
                            if ALLCONP[COT]["3"]:
                                COUNT = ALLCONP[COT]["3"]["count"]
                                COST = ALLCONP[COT]["3"]["cost"]
                                if int(COUNT) > 0 and int(float(COST)) < int(SINGLE):
                                    LISTSM.append(COT)
                        except: pass
                    getl = len(LISTSM)
                    await app.edit_message_text(chat_id,message_id,f"📤Start with {getl} country?\nUnder {SINGLE} Ruble",reply_markup = markup([[button(f"✅Start",callback_data="BUY_RANGE")],[button(f"🔙Back",callback_data="BACK")]]))
                elif SITE == "5sim":
                    try:
                        PRICES = requests.get("https://5sim.net/v1/guest/prices?product=telegram")
                        PRICES = PRICES.json()["telegram"]
                        for COUNTR in PRICES:
                            for OPRS in PRICES[COUNTR]:
                                COSTS = PRICES[COUNTR][OPRS]["cost"]
                                COUNT = PRICES[COUNTR][OPRS]["count"]
                                if int(float(COSTS)) < int(SINGLE) and int(COUNT) > 0: 
                                    try:
                                        LIST5S[COUNTR].append(OPRS)
                                    except:
                                        LIST5S[COUNTR] = []
                                        LIST5S[COUNTR].append(OPRS)
                    except: pass
                    getl = len(LIST5S)
                    await app.edit_message_text(chat_id,message_id,f"📤Start with {getl} country?\nUnder {SINGLE} Ruble",reply_markup = markup([[button(f"✅Start",callback_data="BUY_RANGE")],[button(f"🔙Back",callback_data="BACK")]]))
                else:
                    await app.edit_message_text(chat_id,message_id,f"📤Start with 1 country?\nUnder {SINGLE} Ruble",reply_markup = markup([[button(f"✅Start",callback_data="BUY_RANGE")],[button(f"🔙Back",callback_data="BACK")]]))
            else:
                TYPECR = PLATFORM
                LISTBUT = []
                RAWBUT = []
                if ALLAUTO:
                    await app.edit_message_text(chat_id,message_id,"❌Is active...\nCancel it",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
                    return
                await app.edit_message_text(chat_id,message_id,"Try to get number...")
                try:
                    if SITE == "sa":
                        Brazil = {"73":{"tg":{"cost":0,"count":0}}}
                        Algeria = {"58":{"tg":{"cost":0,"count":0}}}
                        Argentina = {"39":{"tg":{"cost":0,"count":0}}}
                        Philippines = {"4":{"tg":{"cost":0,"count":0}}}
                        Indonesia = {"6":{"tg":{"cost":0,"count":0}}}
                        Pakistan = {"66":{"tg":{"cost":0,"count":0}}}
                        Vietnam = {"10":{"tg":{"cost":0,"count":0}}}
                        Pakistan = {"66":{"tg":{"cost":0,"count":0}}}
                        ALLCONP = ""
                        try:
                            ALLCON = requests.get(f"https://api.sms-activate.org/stubs/handler_api.php?api_key={TOKEN}&action=getPrices&service=tg")
                            ALLCONP = ALLCON.json()
                            await asyncio.sleep(0.1)
                        except: pass
                        BrazilP = ALLCONP["73"]["tg"]["cost"]
                        BrazilC = ALLCONP["73"]["tg"]["count"]
                        AlgeriaP = ALLCONP["58"]["tg"]["cost"]
                        AlgeriaC = ALLCONP["58"]["tg"]["count"]
                        ArgentinaP = ALLCONP["39"]["tg"]["cost"]
                        ArgentinaC = ALLCONP["39"]["tg"]["count"]
                        PhilippinesP = ALLCONP["4"]["tg"]["cost"]
                        PhilippinesC = ALLCONP["4"]["tg"]["count"]
                        IndonesiaP = ALLCONP["6"]["tg"]["cost"]
                        IndonesiaC = ALLCONP["6"]["tg"]["count"]
                        PakistanP = ALLCONP["66"]["tg"]["cost"]
                        PakistanC = ALLCONP["66"]["tg"]["count"]
                        VietnamP = ALLCONP["10"]["tg"]["cost"]
                        VietnamC = ALLCONP["10"]["tg"]["count"]
                        PapuaP = ALLCONP["79"]["tg"]["cost"]
                        PapuaC = ALLCONP["79"]["tg"]["count"]
                        LISTBUT = [[button(f"🇧🇷Brazil-{BrazilP}-{BrazilC}",callback_data=f"BUY_73"),button(f"🇩🇿Algeria-{AlgeriaP}-{AlgeriaC}",callback_data=f"BUY_58")],
                        #[button(f"🇦🇷Argentina-{ArgentinaP}-{ArgentinaC}",callback_data=f"BUY_39"),
                        [button(f"🇵🇭Philippines-{PhilippinesP}-{PhilippinesC}",callback_data=f"BUY_4")],
                        [button(f"🇮🇩Indonesia-{IndonesiaP}-{IndonesiaC}",callback_data=f"BUY_6"),button(f"🇵🇰Pakistan-{PakistanP}-{PakistanC}",callback_data=f"BUY_66")],
                        [button(f"🇻🇳Vietnam-{VietnamP}-{VietnamC}",callback_data=f"BUY_10"),button(f"🇵🇬Papua-{PapuaP}-{PapuaC}",callback_data=f"BUY_79")],
                        [button(f"🔙Back",callback_data="BACK")]
                        ]
                        await app.edit_message_text(chat_id,message_id,"Please select your country\nFormat: NAME-PRICE-COUNT",reply_markup = markup(LISTBUT))
                    elif SITE == "sm":
                        Mozambique = {"80":{"tg":{"cost":0,"count":0}}}
                        Kenya = {"8":{"tg":{"cost":0,"count":0}}}
                        Nigeria = {"19":{"tg":{"cost":0,"count":0}}}
                        Algeria = {"58":{"tg":{"cost":0,"count":0}}}
                        Senegal = {"61":{"tg":{"cost":0,"count":0}}}
                        Ethiopia = {"71":{"tg":{"cost":0,"count":0}}}
                        SouthAfrica = {"31":{"tg":{"cost":0,"count":0}}}
                        Morocco = {"37":{"tg":{"cost":0,"count":0}}}
                        Zimbabwe = {"96":{"tg":{"cost":0,"count":0}}}
                        Madagascar = {"17":{"tg":{"cost":0,"count":0}}}
                        ALLCONP = ""
                        try:
                            ALLCON = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?action=getPrices&api_key={TOKEN}&service=tg")
                            ALLCONP = ALLCON.json()
                            await asyncio.sleep(0.1)
                        except: pass
                        MozambiqueP = ALLCONP["80"]["tg"]["cost"]
                        MozambiqueC = ALLCONP["80"]["tg"]["count"]
                        KenyaP = ALLCONP["8"]["tg"]["cost"]
                        KenyaC = ALLCONP["8"]["tg"]["count"]
                        NigeriaP = ALLCONP["19"]["tg"]["cost"]
                        NigeriaC = ALLCONP["19"]["tg"]["count"]
                        AlgeriaP = ALLCONP["58"]["tg"]["cost"]
                        AlgeriaC = ALLCONP["58"]["tg"]["count"]
                        SenegalP = ALLCONP["61"]["tg"]["cost"]
                        SenegalC = ALLCONP["61"]["tg"]["count"]
                        EthiopiaP = ALLCONP["71"]["tg"]["cost"]
                        EthiopiaC = ALLCONP["71"]["tg"]["count"]
                        SouthAfricaP = ALLCONP["31"]["tg"]["cost"]
                        SouthAfricaC = ALLCONP["31"]["tg"]["count"]
                        MoroccoP = ALLCONP["37"]["tg"]["cost"]
                        MoroccoC = ALLCONP["37"]["tg"]["count"]
                        ZimbabweP = ALLCONP["96"]["tg"]["cost"]
                        ZimbabweC = ALLCONP["96"]["tg"]["count"]
                        MadagascarP = ALLCONP["17"]["tg"]["cost"]
                        MadagascarC = ALLCONP["17"]["tg"]["count"]
                        LISTBUT = [[button(f"🇲🇿Mozambique-{MozambiqueP}-{MozambiqueC}",callback_data=f"BUY_80"),button(f"🇰🇪Kenya-{KenyaP}-{KenyaC}",callback_data=f"BUY_8")],
                        [button(f"🇳🇬Nigeria-{NigeriaP}-{NigeriaC}",callback_data=f"BUY_19"),button(f"🇩🇿Algeria-{AlgeriaP}-{AlgeriaC}",callback_data=f"BUY_58")],
                        [button(f"🇸🇳Senegal-{SenegalP}-{SenegalC}",callback_data=f"BUY_61"),button(f"🇪🇹Ethiopia-{EthiopiaP}-{EthiopiaC}",callback_data=f"BUY_71")],
                        [button(f"🇿🇼Zimbabwe-{ZimbabweP}-{ZimbabweC}",callback_data=f"BUY_96"),button(f"🇵🇬Morocco-{MoroccoP}-{MoroccoC}",callback_data=f"BUY_37")],
                        [button(f"🇿🇦SouthAfrica-{SouthAfricaP}-{SouthAfricaC}",callback_data=f"BUY_31"),button(f"🇲🇬Madagascar-{MadagascarP}-{MadagascarC}",callback_data=f"BUY_37")],
                        [button(f"🔙Back",callback_data="BACK")]
                        ]
                        await app.edit_message_text(chat_id,message_id,"Please select your country\nFormat: NAME-PRICE-COUNT",reply_markup = markup(LISTBUT))
                    elif SITE == "5sim":
                        try:
                            PRICES = requests.get("https://5sim.net/v1/guest/prices?product=telegram")
                            PRICES = PRICES.json()["telegram"]
                            INTWO = []
                            for COUNTR in PRICES:
                                for OPRS in PRICES[COUNTR]:
                                    COSTS = PRICES[COUNTR][OPRS]["cost"]
                                    COUNT = PRICES[COUNTR][OPRS]["count"]
                                    if int(float(COSTS)) < 16 and int(COUNT) > 0: 
                                        if len(INTWO) == 2:
                                            RAWBUT.append(INTWO)
                                            INTWO = []
                                            INTWO.append(button(f"🇺🇳{COSTS}-{COUNT}-{OPRS}-{COUNTR}",callback_data=f"BUY_{COUNTR}:{OPRS}"))
                                        else:
                                            INTWO.append(button(f"🇺🇳{COSTS}-{COUNT}-{OPRS}-{COUNTR}",callback_data=f"BUY_{COUNTR}:{OPRS}"))
                                            # RAWBUT.append([button(f"🇺🇳{COSTS}-{COUNT}-{OPRS}-{COUNTR}",callback_data=f"BUY_{COUNTR}:{OPRS}")])
                            if len(INTWO) > 0: 
                                RAWBUT.append(INTWO)
                                INTWO = []
                            RAWBUT.append([button(f"🔙Back",callback_data=f"BACK")])
                        except Exception as e: print(e)
                        except: print("Except")
                        await app.edit_message_text(chat_id,message_id,"Please select your country\nFormat: PRICE-COUNT-OPR-NAME",reply_markup = markup(RAWBUT))
                    else:
                        try:
                            PRICES = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=getNumbersStatus")
                            PRICES = str(PRICES.json()["tg_0"])
                            print(PRICES)
                            LISTBUT = [[button(f"🇺🇳USA|CANADA-{PRICES}",callback_data=f"BUY_all")],[button(f"🔙Back",callback_data=f"BACK")]]
                            await app.edit_message_text(chat_id,message_id,"Please select your country\nFormat: NAME-COUNT",reply_markup = markup(LISTBUT))
                        except Exception as e: print(e)
                        except: pass
                except Exception as e: print(e)
                except:
                    await app.edit_message_text(chat_id,message_id,"❌Have problem to get data",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
        elif "receive_" in str(data):
            try:
                PHONE = str(data).replace("receive_","")
                _thread = threading.Thread(target=Between_Get, args=[PHONE,chat_id]).start()
                await app.edit_message_text(chat_id,message_id,f"♻️Ready for getting code\nEnter phone number +{PHONE} in your telegram to get your code")
            except:
                await app.edit_message_text(chat_id,message_id,f"❌There is a problem to get code for phone number +{PHONE}\n Try after a while",reply_markup = markup([[button("♻️Receive Code",callback_data=f"receive_{PHONE}")]]))
        elif "BUY_" in str(data):
            for XNX in db.smembers("LISTTHE"):
                db.srem("LISTTHE",XNX)
                os.system(f"screen -S PHONE-{XNX} -X kill")
            COUNTBUY = COUNTCODE#
            GDATA = str(data).replace("BUY_","")
            ACTIVEOP = "any"
            if GDATA != "RANGE":
                if SITE == "sm":
                    ACTIVEOP = "any"
                    COUNTBUY = GDATA
                elif SITE == "sa":
                    ACTIVEOP = "any"
                    COUNTBUY = GDATA
                elif SITE == "5sim":
                    GDATA = GDATA.split(":")
                    ACTIVEOP = GDATA[1]
                    COUNTBUY = GDATA[0]
                else:
                    ACTIVEOP = "any"
                    COUNTBUY = "12"
            ALLAUTO = True
            await app.edit_message_text(chat_id,message_id,f"♻️Creating Loop started!",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
            THELASTOP = 0
            MAXLOOP = 5
            if db.get("MAXLOOP"):
                MAXLOOP = int(db.get("MAXLOOP"))
            ISNONUM = False
            while True:
                if ALLAUTO == False:
                    break
                if db.scard("CREATED") > 0:
                    try:
                        for XC in db.smembers("CREATED"):
                            db.srem("CREATED",XC)
                            XC = XC.split(":")
                            PHONEC1 = XC[0]
                            TYPEC1 = XC[1]
                            CODEC1 = XC[2]
                            await app.send_message(chat_id,f"✅One number created!\nPhone: {PHONEC1}\nCode: {CODEC1}\nPlatform: {TYPEC1}")
                    except: pass
                if db.scard("BANNED") > 0:
                    try:
                        for XC in db.smembers("BANNED"):
                            db.srem("BANNED",XC)
                            await app.send_message(chat_id,f"❌One number is ban\nPhone: {XC}")
                    except: pass
                if db.scard("AFTERTIME") > 0:
                    try:
                        for XC in db.smembers("AFTERTIME"):
                            db.srem("AFTERTIME",XC)
                            await app.send_message(chat_id,f"⚠️One number is timeout\nPhone: {XC}")
                    except: pass
                LISTTHEX = db.scard("LISTTHE")
                if LISTTHEX > 0:
                    for XLT in db.smembers("LISTTHE"):
                        if db.get(f"THE{XLT}"):
                            XLTS = db.get(f"THE{XLT}")
                            XLTS = XLTS.split(":")
                            TIMS = int(XLTS[0])
                            if TIMS < int(float(time.time())):
                                IDMS = XLTS[1]
                                SITS = XLTS[2]
                                PHNS = XLTS[3]
                                if SITS == "5sim":
                                    headers = {'Authorization': 'Bearer ' + S5TOKEN,'Accept': 'application/json',}
                                    DELETE = requests.get(f"https://5sim.net/v1/user/ban/{IDMS}", headers=headers)
                                elif SITS == "sa":
                                    DELETE = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={SATOKEN}&action=setStatus&status=8&id={IDMS}")
                                elif SITS == "sm":
                                    DELETE = requests.get(f"https://api.sms-man.com/control/set-status?token={SMTOKEN}&request_id={IDMS}&status=reject")
                                else:
                                    DELETE = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={SCTOKEN}&action=setStatus&status=8&id={IDMS}")
                                db.srem("LISTTHE",XLT)
                                os.system(f"screen -S PHONE-{XLT} -X kill")
                                db.delete(f"THE{XLT}")
                                await app.send_message(chat_id,f"⚠️One number is timeout\nPhone: {PHNS}")
                if LISTTHEX < MAXLOOP:
                    if GDATA == "RANGE":
                        if SITE == "sm":
                            ACTIVEOP = "any"
                            COUNTBUY = random.choice(LISTSM)
                        elif SITE == "sa":
                            ACTIVEOP = "any"
                            COUNTBUY = random.choice(LISTSA)
                        elif SITE == "5sim":
                            COUNTBUY = random.choice(list(LIST5S))
                            ACTIVEOP = random.choice(LIST5S[COUNTBUY])
                        else:
                            ACTIVEOP = "any"
                            COUNTBUY = "12"
                    try:
                        BUYSC = ""
                        if SITE != "5sim":
                            if SITE == "sa":
                                BUYS = requests.get(f"https://api.sms-activate.org/stubs/handler_api.php?api_key={TOKEN}&action=getNumber&service=tg&country={COUNTBUY}")
                                BUYSC = str(BUYS.content)
                            elif SITE == "sc":
                                BUYS = requests.get(f"https://sms-code.store/stubs/handler_api.php?api_key={TOKEN}&action=getNumber&service=tg&country={COUNTBUY}")
                                BUYSC = str(BUYS.content)
                            elif SITE == "sm":
                                BUYS = requests.get(f"https://api.sms-man.com/control/get-number?token={TOKEN}&country_id={COUNTBUY}&application_id=3")
                                # BUYS = requests.get(f"http://api.sms-man.com/stubs/handler_api.php?api_key={TOKEN}&action=getNumber&service=tg&country={COUNTBUY}")
                                # BUYSC = str(BUYS.content)
                                BUYSC = ""
                                try:
                                    BUYSC = BUYS.json()
                                    print(BUYSC)
                                    if BUYSC["number"]:
                                        BUYSC = "ACCESS_NUMBER:" + str(BUYSC["request_id"]) + ":" + str(BUYSC["number"])
                                    else:
                                        BUYSC = "NO_NUMBERS"
                                except Exception as e:
                                    print(e)
                                    BUYSC = "NO_NUMBERS"
                                except:
                                    print("Except")
                                    BUYSC = "NO_NUMBERS"
                            if "ACCESS_NUMBER" in BUYSC:
                                DATAS = BUYSC.split(":")
                                ID = DATAS[1]
                                PHONE = DATAS[2]
                                PHONE = PHONE.replace("'","").replace("+","")
                                await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n♻️Checking: {PHONE}")#,reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
                                print(PHONE)
                                if "no such column: number" in str(PHONE):
                                    ISNONUM = True
                                    try:
                                        print("FUCK IT\nNo number")
                                        await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n❌No number!")
                                    except: pass
                                else:
                                    if GLOBTHE >= 50:
                                        GLOBTHE = 0
                                    GLOBTHE = GLOBTHE + 1
                                    await app.send_message(chat_id,f"♻️Start thread {GLOBTHE}:\nPhone: {PHONE}\nPlatform: {TYPECR}")
                                    db.set(f"THE{GLOBTHE}",str(int(float(time.time())) + 200) + ":" + str(ID) + ":" + str(SITE) + ":" + str(PHONE))
                                    print(f"screen -d -m -S PHONE-{GLOBTHE} python3.8 create.py {TYPECR} {PHONE} {ID} {ACTIVEOP} {chat_id} {GLOBTHE} {api_id} {api_hash} {SITE}")
                                    os.system(f"screen -d -m -S PHONE-{GLOBTHE} python3.8 create.py {TYPECR} {PHONE} {ID} {ACTIVEOP} {chat_id} {GLOBTHE} {api_id} {api_hash} {SITE}")
                            elif "NO_BALANCE" in BUYSC:
                                try:
                                    await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n❌No balance!")
                                except: pass
                            elif "NO_NUMBERS" in BUYSC:
                                print("Change OP")
                                ISNONUM = True
                                try:
                                    await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n❌No number!")
                                except: pass
                            else:
                                print(BUYSC)
                                try:
                                    await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n❌Error!")
                                except: pass
                        else:
                            headers = {'Authorization': 'Bearer ' + TOKEN,'Accept': 'application/json',}
                            BUYS = requests.get(f"https://5sim.net/v1/user/buy/activation/{COUNTBUY}/{ACTIVEOP}/telegram", headers=headers)
                            BUYSC = BUYS.json()
                            print(BUYS.content)
                            if BUYSC["status"] == "PENDING" or BUYSC["status"] == "RECEIVED":
                                ID = BUYSC["id"]
                                PHONE = str(BUYSC["phone"]).replace("+","")
                                await app.edit_message_text(chat_id,message_id,f"♻️Looping!\n♻️Checking: {PHONE}\n🪄Operator: {ACTIVEOP}")#,reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
                                print(PHONE)
                                if "no such column: number" in str(PHONE):
                                    print("FUCK IT\nNo number")
                                    ISNONUM = True
                                else:
                                    if GLOBTHE >= 50:
                                        GLOBTHE = 0
                                    GLOBTHE = GLOBTHE + 1
                                    await app.send_message(chat_id,f"♻️Start thread {GLOBTHE}:\nPhone: {PHONE}\nPlatform: {TYPECR}")
                                    db.set(f"THE{GLOBTHE}",str(int(float(time.time())) + 200) + ":" + str(ID) + ":" + str(SITE) + ":" + str(PHONE))
                                    print(f"screen -d -m -S PHONE-{GLOBTHE} python3.8 create.py {TYPECR} {PHONE} {ID} {ACTIVEOP} {chat_id} {GLOBTHE} {api_id} {api_hash} {SITE}")
                                    os.system(f"screen -d -m -S PHONE-{GLOBTHE} python3.8 create.py {TYPECR} {PHONE} {ID} {ACTIVEOP} {chat_id} {GLOBTHE} {api_id} {api_hash} {SITE}")
                            else:
                                ISNONUM = True
                                print(BUYS.content)
                    except Exception as e:
                        print(e)
                        try:
                            await app.edit_message_text(chat_id,message_id,"❌No number",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
                        except: pass
                    except:
                        try:
                            await app.edit_message_text(chat_id,message_id,"❌No number",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
                        except: pass
                if ISNONUM == True:
                    ISNONUM = False
                    await asyncio.sleep(1)
                else:
                    await asyncio.sleep(5)
        elif "CANCEL_" in str(data):
            try:
                ID = str(data).replace("CANCEL_","")
                PHONE = GLOBALD[ID]["phone"]
                client = SESSIONS[PHONE]
                CANCEL = requests.get(f"https://sms-activate.ru/stubs/handler_api.php?api_key={TOKEN}&action=setStatus&status=8&id={ID}")
                del GLOBALD[ID]
                await app.edit_message_text(chat_id,message_id,f"❌Number Canceled\n\nPhone: +{PHONE}\nID: {ID}",reply_markup = markup([[button(f"📤Go to buy list",callback_data="GETHIT")],[button(f"🔙Back",callback_data="BACK")]]))
                try:
                    await client.disconnect()
                except: pass
                try:
                    await client.stop()
                except: pass
                TOR = GLOBALD[ID]["tor"]
                TOR.kill()
            except:
                await app.edit_message_text(chat_id,message_id,"❌Have problem to get data",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif data == "GRNUM":
        if db.sismember("BUSER",str(chat_id)) and db.get(str(chat_id)) and db.scard("PHONESALL") > 0:
            if int(db.get(str(chat_id))) == 0:
                db.srem("BUSER",str(chat_id))
                await app.edit_message_text(chat_id,message_id,"⚠️Your capacity is over")
                return 
            try:
                if ALLLISTGET[str(chat_id)] and ALLLISTGET[str(chat_id)] == True:
                    await app.edit_message_text(chat_id,message_id,"⚠️You have an number in waiting...")
                    return 
            except: pass
            try:
                GETPLAT = db.get(str(chat_id) + "T")
                if not GETPLAT:
                    GETPLAT = "PYRO"
                PHONE = ""
                for XPH in db.smembers("PHONESALL"):
                    if GETPLAT == "THON" and db.get(XPH):
                        PHONE = XPH
                    elif GETPLAT == "PYRO" and not db.get(XPH):   
                        PHONE = XPH
                db.srem("PHONESALL",PHONE)
                ALLLISTGET[str(chat_id)] = True
                _thread = threading.Thread(target=Between_Get, args=[PHONE,chat_id]).start()
                await app.edit_message_text(chat_id,message_id,f"♻️Ready for getting code\nEnter phone number +{PHONE} in your telegram to get your code")
            except Exception as e:
                print(e)
                await app.edit_message_text(chat_id,message_id,f"❌There is a problem\n Try after a while",reply_markup = markup([[button("♻️Try again",callback_data=f"GRNUM")]]))
            except:
                await app.edit_message_text(chat_id,message_id,f"❌There is a problem\n Try after a while",reply_markup = markup([[button("♻️Try again",callback_data=f"GRNUM")]]))
        else:
            await app.edit_message_text(chat_id,message_id,"⚠️Something going wrong")
    else:
        await app.edit_message_text(chat_id,message_id,"You can not use this robot")
        
@app.on_message(filters.photo, group=2)
async def get_file(cli, message):
    global STEPALL
    global GLOBALID
    # global ALLKILL
    # global AUTOLAUNCH
    # if ALLKILL or int(time.time()) > AUTOLAUNCH:
        # ALLKILL = True
        # sys.exit()
    chat_id = message.chat.id 
    if STEPALL == "PHOTOADD" and GLOBALID == chat_id:
        file_dir = await app.download_media(message) 
        db.sadd("PHOTOS",str(file_dir))
        await app.send_message(chat_id,f"Photo with local address {file_dir} added to list\nAny photo? send it",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    elif STEPALL == "SERIADD" and GLOBALID == chat_id:
        global SERIIDS
        file_dir = await app.download_media(message) 
        if not db.sismember("SERI",str(SERIIDS)):
            db.sadd("SERI",str(SERIIDS))
        db.sadd(str(SERIIDS),str(file_dir))
        await app.send_message(chat_id,f"Photo with local address {file_dir} added to seri {SERIIDS}\nAny photo? send it",reply_markup = markup([[button(f"🔙Back",callback_data="BACK")]]))
    
app.start()
print("Running Bot...")
idle()
app.stop()