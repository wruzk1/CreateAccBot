screen -S AUTONUM -X kill
screen -d -m -S AUTONUM python3.8 bot.py
